const STEPS = [
  {
    title: "Eliges modelo y pack",
    text: "Placa o expositor, estándar o con el vinilo de tu negocio.",
  },
  {
    title: "Nos pasas tu enlace de Google",
    text: "Por WhatsApp. Si eliges la versión personalizada, también tu logo.",
  },
  {
    title: "La recibes lista para usar",
    text: "Programada con tu enlace. La colocas y tus clientes ya pueden dejarte su reseña.",
  },
];

export default function HowItWorks() {
  return (
    <section id="como-funciona" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:py-24">
      <h2 className="max-w-2xl text-3xl font-semibold sm:text-4xl lg:text-[2.8rem] lg:leading-[1.08]">
        Empezar es así de fácil
      </h2>

      <ol className="relative mt-12 grid gap-10 md:grid-cols-3 md:gap-8">
        <span
          aria-hidden="true"
          className="absolute left-[1.35rem] top-6 hidden h-px w-[calc(100%-4rem)] bg-gradient-to-r from-brand via-line to-transparent md:block"
        />
        {STEPS.map((s, i) => (
          <li key={s.title} className="relative flex gap-5 md:block">
            <span className="relative z-10 grid h-11 w-11 shrink-0 place-items-center rounded-full border border-brand bg-bg font-display text-lg font-semibold text-brand">
              {i + 1}
            </span>
            <div className="md:mt-6">
              <h3 className="font-display text-xl font-semibold">{s.title}</h3>
              <p className="mt-2 text-mute">{s.text}</p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
