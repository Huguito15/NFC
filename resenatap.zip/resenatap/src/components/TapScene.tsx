"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { CheckIcon, StarIcon } from "./icons";

/**
 * Escena del hero: un móvil se acerca a la tarjeta NFC, el cliente puntúa
 * con cinco estrellas y la reseña queda enviada. Se repite en bucle.
 *
 * Etapas:
 *  0 reposo · 1 el móvil se acerca · 2 toque (ondas) · 3 estrellas
 *  4 reseña enviada · 5 el móvil se retira
 */
type Stage = 0 | 1 | 2 | 3 | 4 | 5;

const AMBER = "#FBBF24";
const STAR_OFF = "#CBD5E1";

// Tamaños en cqw: la escena escala entera con su contenedor.
const cq = (n: number) => `${n}cqw`;

export default function TapScene() {
  const reduce = useReducedMotion();
  const [stage, setStage] = useState<Stage>(0);

  useEffect(() => {
    if (reduce) {
      setStage(4);
      return;
    }
    let alive = true;
    const timers: ReturnType<typeof setTimeout>[] = [];
    const at = (ms: number, s: Stage) =>
      timers.push(setTimeout(() => alive && setStage(s), ms));

    const run = () => {
      timers.length = 0;
      at(0, 0);
      at(800, 1);
      at(1900, 2);
      at(2500, 3);
      at(3900, 4);
      at(6600, 5);
      timers.push(setTimeout(() => alive && run(), 7600));
    };
    run();

    return () => {
      alive = false;
      timers.forEach(clearTimeout);
    };
  }, [reduce]);

  const phoneNear = stage >= 1 && stage <= 4;
  const filling = stage >= 3;
  const thanks = stage === 4;
  const showReview = stage >= 2 && stage <= 4;
  const showRings = stage === 2 || stage === 3;

  return (
    <div
      role="img"
      aria-label="Animación: un cliente acerca el móvil a la tarjeta NFC, puntúa con cinco estrellas y su reseña queda enviada."
      className="relative mx-auto aspect-square w-full max-w-[560px] select-none"
      style={{ containerType: "inline-size" }}
    >
      {/* Resplandor de fondo */}
      <div className="absolute inset-[8%] rounded-full bg-glow/25 blur-3xl" />
      <div className="absolute inset-[22%] rounded-full bg-brand-strong/30 blur-3xl" />

      {/* TARJETA */}
      <div className="absolute left-[3%] top-[14%] w-[68%] animate-drift">
        <div
          className="relative aspect-[1/1] -rotate-3 overflow-hidden border border-line bg-surface shadow-soft"
          style={{ borderRadius: cq(5) }}
        >
          {/* Banda superior */}
          <div
            className="relative bg-gradient-to-br from-brand-strong to-[#1237a8] text-white"
            style={{ padding: `${cq(4.2)} ${cq(5)} ${cq(8)}` }}
          >
            <p className="font-display font-semibold leading-tight" style={{ fontSize: cq(4.6) }}>
              ¿Te ha gustado?
              <br />
              Déjanos tu reseña
            </p>
            <div className="mt-[2.2cqw] flex" style={{ gap: cq(0.8), color: AMBER }}>
              {Array.from({ length: 5 }).map((_, i) => (
                <StarIcon key={i} style={{ width: cq(4.2), height: cq(4.2) }} />
              ))}
            </div>
            {/* Curva */}
            <svg
              viewBox="0 0 100 12"
              preserveAspectRatio="none"
              className="absolute inset-x-0 bottom-[-1px] w-full text-surface"
              style={{ height: cq(6) }}
              aria-hidden="true"
            >
              <path d="M0 12V6c18-8 34-8 50-2s34 6 50-2v10Z" fill="currentColor" />
            </svg>
          </div>

          {/* Zona NFC */}
          <div className="flex flex-col items-center" style={{ paddingTop: cq(2) }}>
            <svg viewBox="0 0 64 64" style={{ width: cq(19), height: cq(19) }} aria-hidden="true">
              <g fill="none" stroke="rgb(var(--brand))" strokeWidth="3.4" strokeLinecap="round">
                <path d="M22 41c5.6-6.8 5.6-15.2 0-22" />
                <path d="M31 46c8.4-10 8.4-22 0-32" />
                <path d="M40 51c11.2-13.2 11.2-29.8 0-43" />
              </g>
            </svg>
            <p className="font-display font-semibold text-ink" style={{ fontSize: cq(4.2), marginTop: cq(1.2) }}>
              Acerca tu móvil
            </p>
          </div>
        </div>
      </div>

      {/* ONDAS del toque */}
      <div
        className="pointer-events-none absolute"
        style={{ left: "36%", top: "54%", width: cq(26), height: cq(26), transform: "translate(-50%,-50%)" }}
      >
        <AnimatePresence>
          {showRings &&
            [0, 1, 2].map((i) => (
              <motion.span
                key={i}
                className="absolute inset-0 rounded-full border-2 border-glow"
                initial={{ scale: 0.25, opacity: 0.85 }}
                animate={{ scale: 2.6, opacity: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.3, delay: i * 0.22, ease: "easeOut" }}
              />
            ))}
        </AnimatePresence>
      </div>

      {/* MÓVIL */}
      <motion.div
        className="absolute"
        style={{ right: "3%", bottom: "4%", width: "31%" }}
        initial={false}
        animate={
          phoneNear
            ? { x: "-118%", y: "-6%", rotate: -4 }
            : { x: "0%", y: "14%", rotate: 9 }
        }
        transition={{ type: "spring", stiffness: 62, damping: 15, mass: 0.9 }}
      >
        <div
          className="relative aspect-[9/18.5] border-[#1c2a52] bg-[#080d1c] shadow-[0_30px_60px_-20px_rgba(0,0,0,0.7)]"
          style={{ borderWidth: cq(0.9), borderRadius: cq(5.4), padding: cq(0.9) }}
        >
          {/* Isla */}
          <div
            className="absolute left-1/2 z-10 -translate-x-1/2 bg-black"
            style={{ top: cq(1.6), width: cq(7), height: cq(1.9), borderRadius: cq(2) }}
          />
          <div className="relative h-full w-full overflow-hidden bg-white text-[#0b1430]" style={{ borderRadius: cq(4.6) }}>
            <AnimatePresence mode="wait" initial={false}>
              {!showReview ? (
                <motion.div
                  key="lock"
                  className="absolute inset-0 flex flex-col items-center bg-gradient-to-b from-[#1d4ed8] to-[#0b1430] text-white"
                  style={{ paddingTop: cq(8) }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <span className="font-display font-semibold" style={{ fontSize: cq(7.5) }}>
                    9:41
                  </span>
                  <span className="opacity-70" style={{ fontSize: cq(2.4) }}>
                    Sábado
                  </span>
                </motion.div>
              ) : (
                <motion.div
                  key="review"
                  className="absolute inset-0 flex flex-col"
                  style={{ padding: `${cq(7.5)} ${cq(2.6)} ${cq(2.6)}` }}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.28, ease: "easeOut" }}
                >
                  <AnimatePresence mode="wait" initial={false}>
                    {!thanks ? (
                      <motion.div
                        key="form"
                        className="flex flex-1 flex-col"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.18 }}
                      >
                        <span className="font-display font-semibold leading-tight" style={{ fontSize: cq(3) }}>
                          Tu negocio
                        </span>
                        <span className="text-[#5b6b8f]" style={{ fontSize: cq(2.1), marginTop: cq(0.6) }}>
                          ¿Qué tal ha ido?
                        </span>
                        <div className="flex" style={{ gap: cq(0.5), marginTop: cq(2.2) }}>
                          {Array.from({ length: 5 }).map((_, i) => (
                            <motion.span
                              key={i}
                              className="inline-block"
                              animate={{
                                color: filling ? AMBER : STAR_OFF,
                                scale: filling ? [1, 1.4, 1] : 1,
                              }}
                              transition={{ duration: 0.35, delay: filling ? i * 0.16 : 0 }}
                            >
                              <StarIcon style={{ width: cq(4.3), height: cq(4.3) }} />
                            </motion.span>
                          ))}
                        </div>
                        <div style={{ marginTop: cq(2.6) }} className="space-y-[1.2cqw]">
                          <div className="rounded-full bg-[#e6ecf8]" style={{ height: cq(1.4), width: "92%" }} />
                          <div className="rounded-full bg-[#e6ecf8]" style={{ height: cq(1.4), width: "70%" }} />
                        </div>
                        <div
                          className="mt-auto text-center font-semibold text-white"
                          style={{
                            fontSize: cq(2.3),
                            padding: `${cq(1.4)} 0`,
                            borderRadius: cq(3),
                            background: "#2f6bff",
                          }}
                        >
                          Publicar
                        </div>
                      </motion.div>
                    ) : (
                      <motion.div
                        key="thanks"
                        className="flex flex-1 flex-col items-center justify-center text-center"
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ type: "spring", stiffness: 220, damping: 18 }}
                      >
                        <span
                          className="grid place-items-center rounded-full text-white"
                          style={{ width: cq(9), height: cq(9), background: "#16a34a" }}
                        >
                          <CheckIcon style={{ width: cq(5.4), height: cq(5.4) }} strokeWidth={2.6} />
                        </span>
                        <span className="font-display font-semibold leading-tight" style={{ fontSize: cq(3), marginTop: cq(2.2) }}>
                          ¡Gracias por
                          <br />
                          tu reseña!
                        </span>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </motion.div>

      {/* AVISO de reseña nueva */}
      <AnimatePresence>
        {thanks && (
          <motion.div
            className="glass absolute flex items-center rounded-full font-semibold text-ink shadow-soft"
            style={{ right: "2%", top: "7%", gap: cq(1.6), padding: `${cq(1.6)} ${cq(3.2)}`, fontSize: cq(3.2) }}
            initial={{ opacity: 0, y: 14, scale: 0.85 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
          >
            <span className="flex" style={{ color: AMBER }}>
              {Array.from({ length: 5 }).map((_, i) => (
                <StarIcon key={i} style={{ width: cq(3.2), height: cq(3.2) }} />
              ))}
            </span>
            Nueva reseña
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
