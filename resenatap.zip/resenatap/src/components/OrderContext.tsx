"use client";

import { createContext, useContext, useMemo, useState } from "react";
import type { ReactNode } from "react";
import type { ModelId, Variant } from "@/lib/config";

type OrderState = {
  model: ModelId;
  variant: Variant;
  setModel: (m: ModelId) => void;
  setVariant: (v: Variant) => void;
};

const OrderContext = createContext<OrderState | null>(null);

export function OrderProvider({ children }: { children: ReactNode }) {
  const [model, setModel] = useState<ModelId>("placa");
  const [variant, setVariant] = useState<Variant>("standard");
  const value = useMemo(() => ({ model, variant, setModel, setVariant }), [model, variant]);
  return <OrderContext.Provider value={value}>{children}</OrderContext.Provider>;
}

export function useOrder() {
  const ctx = useContext(OrderContext);
  if (!ctx) throw new Error("useOrder debe usarse dentro de <OrderProvider>");
  return ctx;
}
