import { ChatIcon } from "./icons";
import { GENERIC_MESSAGE, whatsappLink } from "@/lib/whatsapp";

export default function FinalCta() {
  return (
    <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6 lg:pb-28">
      <div className="relative isolate overflow-hidden rounded-[2rem] border border-line bg-gradient-to-br from-brand-strong/25 via-surface to-surface p-8 sm:p-14">
        <div className="absolute -right-24 -top-24 -z-10 h-72 w-72 rounded-full bg-glow/25 blur-3xl" aria-hidden="true" />
        <h2 className="max-w-2xl text-3xl font-semibold sm:text-4xl lg:text-5xl lg:leading-[1.05]">
          Ponle fácil a tus clientes dejarte una reseña
        </h2>
        <p className="mt-5 max-w-xl text-lg text-mute">
          Escríbenos por WhatsApp con el nombre de tu negocio y te contamos cómo quedaría tu tarjeta.
        </p>
        <a
          href={whatsappLink(GENERIC_MESSAGE)}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-8 inline-flex h-14 items-center justify-center gap-2 rounded-full bg-brand-strong px-8 text-base font-semibold text-on-brand shadow-brand transition-transform hover:-translate-y-0.5"
        >
          <ChatIcon width={20} height={20} />
          Pedir por WhatsApp
        </a>
      </div>
    </section>
  );
}
