import { WHATSAPP_NUMBER } from "./config";

export function whatsappLink(message: string) {
  const text = encodeURIComponent(message);
  const base = WHATSAPP_NUMBER ? `https://wa.me/${WHATSAPP_NUMBER}` : "https://wa.me/";
  return `${base}?text=${text}`;
}

export const GENERIC_MESSAGE =
  "Hola, me interesa una tarjeta NFC para conseguir más reseñas en Google. ¿Me contáis más?";
