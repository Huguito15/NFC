# ReseñaTap

Web de venta de tarjetas NFC para reseñas de Google. Next.js 14 + TypeScript + Tailwind + Framer Motion.

## Arrancar en local

```bash
npm install
npm run dev
```

Abre http://localhost:3000

## Qué editar

Todo lo editable está en `src/lib/config.ts`:

- `BRAND`: nombre provisional.
- `PACKS`: precios de los packs (1, 3 y 5 tarjetas) para estándar y personalizada.
- `MODELS`: textos y fotos de los modelos (las imágenes están en `public/images`).
- `FAQ` y `AUDIENCE`: preguntas y tipos de negocio.

## Variables de entorno (Vercel > Settings > Environment Variables)

| Variable | Para qué | Ejemplo |
| --- | --- | --- |
| `NEXT_PUBLIC_WHATSAPP_NUMBER` | Número que recibe los pedidos, con prefijo y sin `+` ni espacios | `34612345678` |
| `NEXT_PUBLIC_SITE_URL` | URL final de la web (para las previsualizaciones al compartir) | `https://tu-dominio.com` |

Si no pones el número, los botones abren WhatsApp para elegir contacto.

## Subir a Vercel

1. Sube la carpeta a un repositorio de GitHub.
2. En Vercel: Add New > Project > importa el repositorio. Framework: Next.js (se detecta solo).
3. Añade las variables de entorno y pulsa Deploy.
