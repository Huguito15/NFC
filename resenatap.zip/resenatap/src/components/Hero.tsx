"use client";

import { motion, useReducedMotion } from "framer-motion";
import TapScene from "./TapScene";
import { ChatIcon } from "./icons";
import { GENERIC_MESSAGE, whatsappLink } from "@/lib/whatsapp";
import { VARIANTS, eur } from "@/lib/config";

const TRUST = [
  "Sin apps ni baterías",
  "Programada con tu enlace de Google",
  "Pedido por WhatsApp, sin compromiso",
];

export default function Hero() {
  const reduce = useReducedMotion();

  // Una sola secuencia de entrada, rápida: título, texto, botones.
  const item = (i: number) =>
    reduce
      ? {}
      : {
          initial: { opacity: 0, y: 18 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.6, delay: 0.1 + i * 0.12, ease: [0.22, 1, 0.36, 1] as const },
        };

  return (
    <section id="inicio" className="relative isolate overflow-hidden pt-28 sm:pt-32">
      <div className="grid-fade absolute inset-0 -z-10" aria-hidden="true" />

      <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 pb-16 sm:px-6 lg:grid-cols-[1.02fr_0.98fr] lg:gap-6 lg:pb-24">
        <div>
          <motion.h1
            {...item(0)}
            className="text-[2.6rem] font-semibold leading-[1.02] sm:text-6xl lg:text-[4.4rem]"
          >
            Más reseñas en Google con un solo toque
          </motion.h1>

          <motion.p {...item(1)} className="mt-6 max-w-xl text-lg text-mute sm:text-xl">
            Tus clientes acercan el móvil a la tarjeta NFC y llegan directos a tu ficha de Google para valorarte.
            Sin apps y sin buscarte.
          </motion.p>

          <motion.div {...item(2)} className="mt-9 flex flex-col gap-3 sm:flex-row">
            <a
              href="#packs"
              className="inline-flex h-14 items-center justify-center rounded-full bg-brand-strong px-8 text-base font-semibold text-on-brand shadow-brand transition-transform hover:-translate-y-0.5"
            >
              Ver packs y precios
            </a>
            <a
              href={whatsappLink(GENERIC_MESSAGE)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-14 items-center justify-center gap-2 rounded-full border border-line bg-surface/60 px-8 text-base font-semibold transition-colors hover:border-brand hover:text-brand"
            >
              <ChatIcon width={20} height={20} />
              Hablar por WhatsApp
            </a>
          </motion.div>

          <motion.p {...item(3)} className="mt-5 text-[0.95rem] text-mute">
            Desde {eur(VARIANTS.standard.unitPrice)} la tarjeta. Personalizada con el vinilo de tu negocio, desde{" "}
            {eur(VARIANTS.custom.unitPrice)}.
          </motion.p>

          <motion.ul {...item(4)} className="mt-8 flex flex-col gap-2 text-[0.95rem] sm:flex-row sm:flex-wrap sm:gap-x-6">
            {TRUST.map((t) => (
              <li key={t} className="flex items-center gap-2 text-mute">
                <span className="h-1.5 w-1.5 rounded-full bg-glow" aria-hidden="true" />
                {t}
              </li>
            ))}
          </motion.ul>
        </div>

        <motion.div
          initial={reduce ? false : { opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
        >
          <TapScene />
        </motion.div>
      </div>
    </section>
  );
}
