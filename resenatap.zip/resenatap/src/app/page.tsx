import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Benefits from "@/components/Benefits";
import HowItWorks from "@/components/HowItWorks";
import Models from "@/components/Models";
import Packs from "@/components/Packs";
import Audience from "@/components/Audience";
import Faq from "@/components/Faq";
import FinalCta from "@/components/FinalCta";
import Footer from "@/components/Footer";
import { OrderProvider } from "@/components/OrderContext";

export default function Home() {
  return (
    <OrderProvider>
      <a href="#contenido" className="skip-link">
        Saltar al contenido
      </a>
      <Header />
      <main id="contenido">
        <Hero />
        <Benefits />
        <HowItWorks />
        <Models />
        <Packs />
        <Audience />
        <Faq />
        <FinalCta />
      </main>
      <Footer />
    </OrderProvider>
  );
}
