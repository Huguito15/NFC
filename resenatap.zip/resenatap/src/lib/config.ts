// ----------------------------------------------------------------------
// TODO: todo lo que quieras cambiar (nombre, precios, textos de modelos)
// está en este archivo. No hace falta tocar los componentes.
// ----------------------------------------------------------------------

export const BRAND = "ReseñaTap"; // nombre provisional, cámbialo cuando lo decidas

// Número de WhatsApp SIN "+" ni espacios, con prefijo de país (España = 34).
// Se configura en Vercel: Settings > Environment Variables >
// NEXT_PUBLIC_WHATSAPP_NUMBER = 34XXXXXXXXX
// Si está vacío, el botón abre WhatsApp para elegir contacto (no falla).
export const WHATSAPP_NUMBER = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "";

export type Variant = "standard" | "custom";
export type ModelId = "placa" | "expositor";

export const VARIANTS: Record<
  Variant,
  { label: string; short: string; note: string; unitPrice: number }
> = {
  standard: {
    label: "Estándar",
    short: "Estándar",
    note: "Lista para usar, programada con tu enlace de reseñas.",
    unitPrice: 30,
  },
  custom: {
    label: "Con el vinilo de tu negocio",
    short: "Con tu logo",
    note: "Personalizada con tu logo, programada con tu enlace de reseñas.",
    unitPrice: 40,
  },
};

// Precio total por pack. Las cantidades 3 y 5 son una propuesta de descuento:
// ajústala a tu margen. El precio por unidad y el ahorro se calculan solos.
export const PACKS: { qty: number; totals: Record<Variant, number> }[] = [
  { qty: 1, totals: { standard: 30, custom: 40 } },
  { qty: 3, totals: { standard: 75, custom: 100 } },
  { qty: 5, totals: { standard: 110, custom: 160 } },
];

export const MODELS: {
  id: ModelId;
  name: string;
  tagline: string;
  description: string;
  bullets: string[];
  image: { src: string; width: number; height: number; alt: string };
}[] = [
  {
    id: "placa",
    name: "Placa acrílica NFC",
    tagline: "Cuadrada, azul y blanca",
    description:
      "Una placa de acrílico para dejar fija junto a la caja, el mostrador o la salida. El cliente acerca el móvil y llega directo a tu ficha de Google.",
    bullets: ["Acrílico rígido de formato cuadrado", "Lectura por NFC, sin apps", "Se ve desde lejos, con llamada a la acción"],
    image: {
      src: "/images/placa-nfc.png",
      width: 333,
      height: 256,
      alt: "Mano sosteniendo una placa acrílica cuadrada azul y blanca con un chip NFC para dejar una reseña en Google",
    },
  },
  {
    id: "expositor",
    name: "Expositor NFC + QR",
    tagline: "De mostrador, en negro o blanco",
    description:
      "Un expositor de sobremesa con NFC y código QR. Si el móvil del cliente no lee NFC, escanea el QR y llega al mismo sitio.",
    bullets: ["Se apoya solo en el mostrador o la mesa", "NFC y QR en el mismo soporte", "Disponible en negro o en blanco"],
    image: {
      src: "/images/expositor-nfc.png",
      width: 333,
      height: 280,
      alt: "Dos expositores de sobremesa, uno negro y otro blanco, con chip NFC y código QR para valorar un negocio en Google",
    },
  },
];

export const FAQ: { q: string; a: string }[] = [
  {
    q: "¿Mis clientes necesitan instalar alguna app?",
    a: "No. Acercan el móvil a la tarjeta y se abre tu ficha de Google para escribir la reseña. No hay que instalar ni configurar nada.",
  },
  {
    q: "¿Funciona con iPhone y con Android?",
    a: "Funciona con la mayoría de móviles actuales que tienen NFC. En el expositor, además, hay un código QR para los móviles que no lo lean.",
  },
  {
    q: "¿Qué necesitáis de mi negocio para prepararla?",
    a: "El enlace a tu ficha de Google (o el nombre exacto de tu negocio y tu localidad, y lo buscamos). Si eliges la versión personalizada, también tu logo.",
  },
  {
    q: "¿Cómo funciona la versión con el vinilo de mi negocio?",
    a: "Preparamos la tarjeta con tu logo en vinilo y la programamos con tu enlace. Te enseñamos cómo quedaría antes de hacerla.",
  },
  {
    q: "¿Cuánto tarda y cómo se paga?",
    a: "Haces el pedido por WhatsApp y te confirmamos el plazo exacto y las formas de pago en ese mismo chat, antes de que pagues nada.",
  },
];

export const AUDIENCE = [
  "Cafeterías y restaurantes",
  "Agencias inmobiliarias",
  "Fotógrafos",
  "Clínicas veterinarias",
  "Peluquerías y centros de estética",
  "Talleres",
  "Clínicas y consultas",
  "Tiendas de barrio",
];

export const eur = (n: number) =>
  new Intl.NumberFormat("es-ES", {
    style: "currency",
    currency: "EUR",
    minimumFractionDigits: Number.isInteger(n) ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(n);
