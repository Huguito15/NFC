"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { MODELS } from "@/lib/config";
import { CheckIcon } from "./icons";
import { useOrder } from "./OrderContext";

export default function Models() {
  const { model, setModel } = useOrder();

  return (
    <section id="modelos" className="border-y border-line bg-surface/50">
      <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:py-24">
        <h2 className="max-w-2xl text-3xl font-semibold sm:text-4xl lg:text-[2.8rem] lg:leading-[1.08]">
          Dos modelos, el mismo resultado
        </h2>
        <p className="mt-5 max-w-2xl text-lg text-mute">
          Elige el que mejor encaje en tu local. Los dos se programan con el enlace de reseñas de tu negocio.
        </p>

        <div className="mt-12 grid gap-6 lg:grid-cols-2">
          {MODELS.map((m) => {
            const active = model === m.id;
            return (
              <motion.article
                key={m.id}
                whileHover={{ y: -4 }}
                transition={{ type: "spring", stiffness: 300, damping: 24 }}
                className={`group flex flex-col overflow-hidden rounded-3xl border bg-bg shadow-soft transition-colors ${
                  active ? "border-brand" : "border-line"
                }`}
              >
                <div className="relative overflow-hidden bg-raised">
                  <Image
                    src={m.image.src}
                    width={m.image.width}
                    height={m.image.height}
                    alt={m.image.alt}
                    sizes="(min-width: 1024px) 560px, 100vw"
                    className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
                  />
                </div>

                <div className="flex flex-1 flex-col p-7 sm:p-8">
                  <p className="text-sm text-mute">{m.tagline}</p>
                  <h3 className="mt-1 font-display text-2xl font-semibold">{m.name}</h3>
                  <p className="mt-3 text-mute">{m.description}</p>

                  <ul className="mt-5 space-y-2.5">
                    {m.bullets.map((b) => (
                      <li key={b} className="flex items-start gap-3">
                        <CheckIcon className="mt-1 shrink-0 text-brand" width={18} height={18} />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>

                  <a
                    href="#packs"
                    onClick={() => setModel(m.id)}
                    className="mt-8 inline-flex h-12 items-center justify-center rounded-full border border-brand px-6 font-semibold text-brand transition-colors hover:bg-brand-strong hover:text-on-brand sm:self-start"
                  >
                    Elegir este modelo
                  </a>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
