const ITEMS = [
  {
    title: "Directo a tu ficha",
    text: "La tarjeta abre tu página de reseñas de Google. Nadie tiene que buscarte ni copiar enlaces.",
  },
  {
    title: "En el momento justo",
    text: "Déjala en la caja, el mostrador o la mesa y pide la reseña cuando el cliente se va contento.",
  },
  {
    title: "Funciona siempre",
    text: "No lleva batería ni hay nada que conectar: el cliente acerca el móvil y listo.",
  },
];

export default function Benefits() {
  return (
    <section className="border-y border-line bg-surface/50">
      <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:py-24">
        <div className="max-w-2xl">
          <h2 className="text-3xl font-semibold sm:text-4xl lg:text-[2.8rem] lg:leading-[1.08]">
            Tus clientes están contentos. Solo falta que lo escriban.
          </h2>
          <p className="mt-5 text-lg text-mute">
            La mayoría no deja reseña porque no sabe dónde hacerlo o le da pereza buscar tu negocio. Con la tarjeta, el
            camino se reduce a un toque. Y más reseñas ayudan a que te encuentren y te elijan frente a otros negocios
            de tu zona.
          </p>
        </div>

        <dl className="mt-12 grid gap-px overflow-hidden rounded-3xl border border-line bg-line md:grid-cols-3">
          {ITEMS.map((it) => (
            <div key={it.title} className="bg-bg p-7 sm:p-8">
              <dt className="font-display text-xl font-semibold">{it.title}</dt>
              <dd className="mt-3 text-mute">{it.text}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
