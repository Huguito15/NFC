import { AUDIENCE } from "@/lib/config";

export default function Audience() {
  return (
    <section className="border-y border-line bg-surface/50">
      <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:py-24">
        <h2 className="max-w-3xl text-3xl font-semibold sm:text-4xl lg:text-[2.8rem] lg:leading-[1.08]">
          Ya la usan cafeterías, agencias inmobiliarias y fotógrafos
        </h2>
        <p className="mt-5 max-w-2xl text-lg text-mute">
          Sirve para cualquier negocio donde el cliente pasa por la caja, el mostrador o la mesa:
        </p>

        <ul className="mt-8 flex flex-wrap gap-3">
          {AUDIENCE.map((a) => (
            <li key={a} className="rounded-full border border-line bg-bg px-5 py-2.5 text-[0.95rem]">
              {a}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
