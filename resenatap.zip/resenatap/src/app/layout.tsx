import type { Metadata, Viewport } from "next";
import "@fontsource-variable/bricolage-grotesque";
import "@fontsource-variable/instrument-sans";
import "./globals.css";
import { BRAND, PACKS } from "@/lib/config";

const siteUrl =
  process.env.NEXT_PUBLIC_SITE_URL ??
  (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : undefined);

const TITLE = `Tarjetas NFC para reseñas de Google | ${BRAND}`;
const DESCRIPTION =
  "Tus clientes acercan el móvil y dejan su reseña en Google al instante. Tarjetas NFC desde 30 €, personalizables con el logo de tu negocio.";

export const metadata: Metadata = {
  ...(siteUrl ? { metadataBase: new URL(siteUrl) } : {}),
  title: TITLE,
  description: DESCRIPTION,
  openGraph: {
    type: "website",
    locale: "es_ES",
    siteName: BRAND,
    title: TITLE,
    description: DESCRIPTION,
    images: [{ url: "/images/placa-nfc.png", width: 333, height: 256, alt: "Placa NFC para reseñas de Google" }],
  },
  twitter: { card: "summary_large_image", title: TITLE, description: DESCRIPTION },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#060b18" },
    { media: "(prefers-color-scheme: light)", color: "#f5f8ff" },
  ],
};

// Aplica el tema guardado antes de pintar para evitar el parpadeo.
const themeScript = `(function(){try{var t=localStorage.getItem('theme');if(t==='light'||t==='dark'){document.documentElement.setAttribute('data-theme',t)}}catch(e){}})();`;

const prices = PACKS.flatMap((p) => Object.values(p.totals));
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Product",
  name: "Tarjeta NFC para reseñas de Google",
  description: DESCRIPTION,
  ...(siteUrl
    ? { image: ["/images/placa-nfc.png", "/images/expositor-nfc.png"].map((p) => `${siteUrl}${p}`) }
    : {}),
  offers: {
    "@type": "AggregateOffer",
    priceCurrency: "EUR",
    lowPrice: Math.min(...prices),
    highPrice: Math.max(...prices),
    offerCount: prices.length,
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" data-theme="dark" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
