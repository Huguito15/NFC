import { Logo } from "./icons";
import { BRAND } from "@/lib/config";

export default function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-10 text-sm text-mute sm:px-6">
        <div className="flex items-center gap-2.5 font-display text-base font-semibold text-ink">
          <Logo size={24} />
          {BRAND}
        </div>
        <p className="max-w-3xl">
          {BRAND} es un producto independiente y no está afiliado, patrocinado ni respaldado por Google. Google y el
          logotipo de Google son marcas registradas de Google LLC.
        </p>
        <p>© {new Date().getFullYear()} {BRAND}</p>
      </div>
    </footer>
  );
}
