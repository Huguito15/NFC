"use client";

import { AnimatePresence, motion } from "framer-motion";
import { MODELS, PACKS, VARIANTS, eur } from "@/lib/config";
import type { ModelId, Variant } from "@/lib/config";
import { whatsappLink } from "@/lib/whatsapp";
import { ChatIcon, CheckIcon } from "./icons";
import { useOrder } from "./OrderContext";

function Segmented<T extends string>({
  id,
  label,
  value,
  options,
  onChange,
}: {
  id: string;
  label: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div>
      <p id={`${id}-label`} className="mb-2 text-sm text-mute">
        {label}
      </p>
      <div
        role="radiogroup"
        aria-labelledby={`${id}-label`}
        className="inline-flex rounded-full border border-line bg-surface p-1"
      >
        {options.map((o) => {
          const active = o.value === value;
          return (
            <button
              key={o.value}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => onChange(o.value)}
              className={`relative h-11 rounded-full px-5 text-[0.95rem] font-semibold transition-colors ${
                active ? "text-on-brand" : "text-mute hover:text-ink"
              }`}
            >
              {active && (
                <motion.span
                  layoutId={`${id}-pill`}
                  className="absolute inset-0 rounded-full bg-brand-strong shadow-brand"
                  transition={{ type: "spring", stiffness: 420, damping: 34 }}
                />
              )}
              <span className="relative">{o.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function Packs() {
  const { model, variant, setModel, setVariant } = useOrder();
  const modelInfo = MODELS.find((m) => m.id === model)!;
  const v = VARIANTS[variant];

  const perUnit = PACKS.map((p) => p.totals[variant] / p.qty);
  const best = perUnit.indexOf(Math.min(...perUnit));

  return (
    <section id="packs" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:py-24">
      <h2 className="max-w-2xl text-3xl font-semibold sm:text-4xl lg:text-[2.8rem] lg:leading-[1.08]">
        Elige tu pack
      </h2>
      <p className="mt-5 max-w-2xl text-lg text-mute">
        Cuantas más tarjetas pidas, menos pagas por cada una. Útil si tienes varias mesas, varios empleados o más de un
        local.
      </p>

      <div className="mt-10 flex flex-wrap items-end gap-x-8 gap-y-5">
        <Segmented<ModelId>
          id="modelo"
          label="Modelo"
          value={model}
          onChange={setModel}
          options={MODELS.map((m) => ({ value: m.id, label: m.id === "placa" ? "Placa" : "Expositor" }))}
        />
        <Segmented<Variant>
          id="version"
          label="Versión"
          value={variant}
          onChange={setVariant}
          options={(Object.keys(VARIANTS) as Variant[]).map((k) => ({ value: k, label: VARIANTS[k].short }))}
        />
      </div>

      <p className="mt-5 text-mute" aria-live="polite">
        {modelInfo.name}. {v.note}
      </p>

      <div className="mt-8 grid gap-5 md:grid-cols-3">
        {PACKS.map((p, i) => {
          const total = p.totals[variant];
          const unit = total / p.qty;
          const saving = p.qty * v.unitPrice - total;
          const isBest = i === best && p.qty > 1;
          const name = p.qty === 1 ? "1 tarjeta" : `Pack de ${p.qty}`;
          const message = `Hola, quiero ${
            p.qty === 1 ? "1 tarjeta" : `un pack de ${p.qty} tarjetas`
          } (${modelInfo.name}, ${v.label.toLowerCase()}) por ${eur(total)}. Mi negocio es: `;

          return (
            <motion.div
              key={p.qty}
              whileHover={{ y: -4 }}
              transition={{ type: "spring", stiffness: 300, damping: 24 }}
              className={`relative flex flex-col rounded-3xl border bg-surface p-7 shadow-soft ${
                isBest ? "border-brand" : "border-line"
              }`}
            >
              {isBest && (
                <span className="absolute -top-3 left-7 rounded-full bg-brand-strong px-3 py-1 text-sm font-semibold text-on-brand">
                  Mejor precio por tarjeta
                </span>
              )}

              <h3 className="font-display text-xl font-semibold">{name}</h3>

              <div className="mt-5 flex items-baseline gap-2">
                <AnimatePresence mode="wait" initial={false}>
                  <motion.span
                    key={`${variant}-${total}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.18 }}
                    className="font-display text-5xl font-semibold tracking-tight"
                  >
                    {eur(total)}
                  </motion.span>
                </AnimatePresence>
              </div>

              <p className="mt-2 text-mute">
                {p.qty === 1
                  ? "Precio por tarjeta"
                  : `${eur(Math.round(unit * 100) / 100)} por tarjeta${saving > 0 ? ` · ahorras ${eur(saving)}` : ""}`}
              </p>

              <ul className="mt-6 space-y-2.5 text-[0.95rem]">
                {[
                  modelInfo.name,
                  "Programada con tu enlace de Google",
                  variant === "custom" ? "Con el vinilo de tu negocio" : "Lista para usar",
                ].map((t) => (
                  <li key={t} className="flex items-start gap-3">
                    <CheckIcon className="mt-0.5 shrink-0 text-brand" width={18} height={18} />
                    <span>{t}</span>
                  </li>
                ))}
              </ul>

              <a
                href={whatsappLink(message)}
                target="_blank"
                rel="noopener noreferrer"
                className={`mt-8 inline-flex h-12 items-center justify-center gap-2 rounded-full font-semibold transition-transform hover:-translate-y-0.5 ${
                  isBest
                    ? "bg-brand-strong text-on-brand shadow-brand"
                    : "border border-brand text-brand hover:bg-brand-strong hover:text-on-brand"
                }`}
              >
                <ChatIcon width={18} height={18} />
                Pedir este pack
              </a>
            </motion.div>
          );
        })}
      </div>

      <p className="mt-6 text-sm text-mute">
        El pedido se hace por WhatsApp. Antes de pagar te confirmamos el plazo exacto y las formas de pago.
      </p>
    </section>
  );
}
